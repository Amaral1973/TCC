﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace AppMySQL
{
    public partial class FrmAlunoTurma : Form
    {
        MySqlConnection con = new MySqlConnection("server=127.0.0.1;port=3306;database=aula;user id=root;password=;charset=utf8");
        public FrmAlunoTurma()
        {
            InitializeComponent();
            CarregaCbx();
        }

        public void CarregaCbx()
        {
            string alu = "SELECT DISTINCT serie FROM aluno ORDER BY serie";
            MySqlCommand cmd = new MySqlCommand(alu, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            MySqlDataAdapter da = new MySqlDataAdapter(alu, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "aluno");
            cbxTurma.ValueMember = "serie";
            cbxTurma.DisplayMember = "serie";
            cbxTurma.DataSource = ds.Tables["aluno"];
            con.Close();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbxTurma_SelectedIndexChanged(object sender, EventArgs e)
        {
            string turma = cbxTurma.SelectedValue.ToString();
            Aluno aluno = new Aluno();
            List<Aluno> alunos = aluno.listaalunoturma(turma);
            dgvAlunos.DataSource = alunos;
        }
    }
}
