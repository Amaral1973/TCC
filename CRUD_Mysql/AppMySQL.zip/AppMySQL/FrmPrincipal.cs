﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppMySQL
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            Aluno aluno = new Aluno();
            List<Aluno> alunos = aluno.listaaluno();
            dgvAluno.DataSource = alunos;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                Aluno aluno = new Aluno();
                if (aluno.RegistroRepetido(txtNome.Text, txtCelular.Text) == true)
                {
                    MessageBox.Show("Aluno já existe em nossa base de dados!", "Repetido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNome.Text = "";
                    txtCelular.Text = "";
                    txtSerie.Text = "";
                    return;
                }
                else
                {
                    aluno.Inserir(txtNome.Text, txtCelular.Text, txtSerie.Text);
                    MessageBox.Show("Aluno inserido com sucesso!", "Inserir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Aluno> alunos = aluno.listaaluno();
                    dgvAluno.DataSource = alunos;
                    txtNome.Text = "";
                    txtCelular.Text = "";
                    txtSerie.Text = "";
                    this.txtNome.Focus();
                    btnEditar.Enabled = false;
                    btnExcluir.Enabled = false;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Aluno aluno = new Aluno();
                aluno.Localizar(id);
                txtNome.Text = aluno.nome;
                txtCelular.Text = aluno.celular;
                txtSerie.Text = aluno.serie;
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Aluno aluno = new Aluno();
                aluno.Atualizar(id, txtNome.Text, txtCelular.Text, txtSerie.Text);
                MessageBox.Show("Aluno atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Aluno> alunos = aluno.listaaluno();
                dgvAluno.DataSource = alunos;
                txtNome.Text = "";
                txtCelular.Text = "";
                txtSerie.Text = "";
                txtId.Text = "";
                this.txtNome.Focus();
                btnEditar.Enabled = false;
                btnExcluir.Enabled = false;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Aluno aluno = new Aluno();
                aluno.Excluir(id);
                MessageBox.Show("Aluno excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Aluno> alunos = aluno.listaaluno();
                dgvAluno.DataSource = alunos;
                txtNome.Text = "";
                txtCelular.Text = "";
                txtSerie.Text = "";
                txtId.Text = "";
                this.txtNome.Focus();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvAluno_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvAluno.Rows[e.RowIndex];
                this.dgvAluno.Rows[e.RowIndex].Selected = true;
                txtId.Text = row.Cells[0].Value.ToString();
                txtNome.Text = row.Cells[1].Value.ToString();
                txtCelular.Text = row.Cells[2].Value.ToString();
                txtSerie.Text = row.Cells[3].Value.ToString();
            }
            btnEditar.Enabled = true;
            btnExcluir.Enabled = true;
        }

        private void btnAlunoTurma_Click(object sender, EventArgs e)
        {
            FrmAlunoTurma alunoTurma = new FrmAlunoTurma();
            alunoTurma.Show();
        }
    }
}
