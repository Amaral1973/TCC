﻿
namespace CriptoApp
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtxtSenha = new MetroFramework.Controls.MetroTextBox();
            this.mtxtLogin = new MetroFramework.Controls.MetroTextBox();
            this.mlblSenha = new MetroFramework.Controls.MetroLabel();
            this.mlblLogin = new MetroFramework.Controls.MetroLabel();
            this.mbLogin = new MetroFramework.Controls.MetroButton();
            this.mbSair = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // mtxtSenha
            // 
            // 
            // 
            // 
            this.mtxtSenha.CustomButton.Image = null;
            this.mtxtSenha.CustomButton.Location = new System.Drawing.Point(127, 1);
            this.mtxtSenha.CustomButton.Name = "";
            this.mtxtSenha.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.mtxtSenha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.mtxtSenha.CustomButton.TabIndex = 1;
            this.mtxtSenha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtSenha.CustomButton.UseSelectable = true;
            this.mtxtSenha.CustomButton.Visible = false;
            this.mtxtSenha.Lines = new string[0];
            this.mtxtSenha.Location = new System.Drawing.Point(21, 146);
            this.mtxtSenha.MaxLength = 32767;
            this.mtxtSenha.Name = "mtxtSenha";
            this.mtxtSenha.PasswordChar = '*';
            this.mtxtSenha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.mtxtSenha.SelectedText = "";
            this.mtxtSenha.SelectionLength = 0;
            this.mtxtSenha.SelectionStart = 0;
            this.mtxtSenha.ShortcutsEnabled = true;
            this.mtxtSenha.Size = new System.Drawing.Size(149, 23);
            this.mtxtSenha.TabIndex = 12;
            this.mtxtSenha.UseSelectable = true;
            this.mtxtSenha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.mtxtSenha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mtxtLogin
            // 
            // 
            // 
            // 
            this.mtxtLogin.CustomButton.Image = null;
            this.mtxtLogin.CustomButton.Location = new System.Drawing.Point(127, 1);
            this.mtxtLogin.CustomButton.Name = "";
            this.mtxtLogin.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.mtxtLogin.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.mtxtLogin.CustomButton.TabIndex = 1;
            this.mtxtLogin.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtLogin.CustomButton.UseSelectable = true;
            this.mtxtLogin.CustomButton.Visible = false;
            this.mtxtLogin.Lines = new string[0];
            this.mtxtLogin.Location = new System.Drawing.Point(23, 95);
            this.mtxtLogin.MaxLength = 32767;
            this.mtxtLogin.Name = "mtxtLogin";
            this.mtxtLogin.PasswordChar = '\0';
            this.mtxtLogin.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.mtxtLogin.SelectedText = "";
            this.mtxtLogin.SelectionLength = 0;
            this.mtxtLogin.SelectionStart = 0;
            this.mtxtLogin.ShortcutsEnabled = true;
            this.mtxtLogin.Size = new System.Drawing.Size(149, 23);
            this.mtxtLogin.TabIndex = 11;
            this.mtxtLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtLogin.UseSelectable = true;
            this.mtxtLogin.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.mtxtLogin.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mlblSenha
            // 
            this.mlblSenha.AutoSize = true;
            this.mlblSenha.Location = new System.Drawing.Point(21, 124);
            this.mlblSenha.Name = "mlblSenha";
            this.mlblSenha.Size = new System.Drawing.Size(44, 19);
            this.mlblSenha.TabIndex = 10;
            this.mlblSenha.Text = "Senha";
            this.mlblSenha.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // mlblLogin
            // 
            this.mlblLogin.AutoSize = true;
            this.mlblLogin.Location = new System.Drawing.Point(23, 70);
            this.mlblLogin.Name = "mlblLogin";
            this.mlblLogin.Size = new System.Drawing.Size(41, 19);
            this.mlblLogin.TabIndex = 9;
            this.mlblLogin.Text = "Login";
            this.mlblLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // mbLogin
            // 
            this.mbLogin.DisplayFocus = true;
            this.mbLogin.Highlight = true;
            this.mbLogin.Location = new System.Drawing.Point(23, 190);
            this.mbLogin.Name = "mbLogin";
            this.mbLogin.Size = new System.Drawing.Size(111, 23);
            this.mbLogin.TabIndex = 13;
            this.mbLogin.Text = "Login";
            this.mbLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbLogin.UseSelectable = true;
            this.mbLogin.Click += new System.EventHandler(this.mbLogin_Click);
            // 
            // mbSair
            // 
            this.mbSair.DisplayFocus = true;
            this.mbSair.Highlight = true;
            this.mbSair.Location = new System.Drawing.Point(156, 190);
            this.mbSair.Name = "mbSair";
            this.mbSair.Size = new System.Drawing.Size(111, 23);
            this.mbSair.TabIndex = 14;
            this.mbSair.Text = "Sair";
            this.mbSair.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbSair.UseSelectable = true;
            this.mbSair.Click += new System.EventHandler(this.mbSair_Click);
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 232);
            this.Controls.Add(this.mbSair);
            this.Controls.Add(this.mbLogin);
            this.Controls.Add(this.mtxtSenha);
            this.Controls.Add(this.mtxtLogin);
            this.Controls.Add(this.mlblSenha);
            this.Controls.Add(this.mlblLogin);
            this.Name = "FrmLogin";
            this.Style = MetroFramework.MetroColorStyle.Green;
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox mtxtSenha;
        private MetroFramework.Controls.MetroTextBox mtxtLogin;
        private MetroFramework.Controls.MetroLabel mlblSenha;
        private MetroFramework.Controls.MetroLabel mlblLogin;
        private MetroFramework.Controls.MetroButton mbLogin;
        private MetroFramework.Controls.MetroButton mbSair;
    }
}