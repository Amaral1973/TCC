﻿
namespace CriptoApp
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MgUsuario = new MetroFramework.Controls.MetroGrid();
            this.mbInserir = new MetroFramework.Controls.MetroButton();
            this.mbEditar = new MetroFramework.Controls.MetroButton();
            this.mbExcluir = new MetroFramework.Controls.MetroButton();
            this.mbSair = new MetroFramework.Controls.MetroButton();
            this.mlblLogin = new MetroFramework.Controls.MetroLabel();
            this.mlblSenha = new MetroFramework.Controls.MetroLabel();
            this.mtxtLogin = new MetroFramework.Controls.MetroTextBox();
            this.mtxtSenha = new MetroFramework.Controls.MetroTextBox();
            this.mtxtId = new MetroFramework.Controls.MetroTextBox();
            this.mlblId = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.MgUsuario)).BeginInit();
            this.SuspendLayout();
            // 
            // MgUsuario
            // 
            this.MgUsuario.AllowUserToAddRows = false;
            this.MgUsuario.AllowUserToDeleteRows = false;
            this.MgUsuario.AllowUserToResizeRows = false;
            this.MgUsuario.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.MgUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MgUsuario.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.MgUsuario.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MgUsuario.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.MgUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MgUsuario.DefaultCellStyle = dataGridViewCellStyle2;
            this.MgUsuario.EnableHeadersVisualStyles = false;
            this.MgUsuario.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.MgUsuario.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.MgUsuario.Location = new System.Drawing.Point(10, 171);
            this.MgUsuario.Name = "MgUsuario";
            this.MgUsuario.ReadOnly = true;
            this.MgUsuario.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MgUsuario.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.MgUsuario.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.MgUsuario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.MgUsuario.Size = new System.Drawing.Size(406, 150);
            this.MgUsuario.TabIndex = 0;
            this.MgUsuario.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MgUsuario_CellClick);
            // 
            // mbInserir
            // 
            this.mbInserir.DisplayFocus = true;
            this.mbInserir.Highlight = true;
            this.mbInserir.Location = new System.Drawing.Point(305, 34);
            this.mbInserir.Name = "mbInserir";
            this.mbInserir.Size = new System.Drawing.Size(111, 23);
            this.mbInserir.TabIndex = 1;
            this.mbInserir.Text = "Inserir";
            this.mbInserir.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbInserir.UseSelectable = true;
            this.mbInserir.Click += new System.EventHandler(this.mbInserir_Click);
            // 
            // mbEditar
            // 
            this.mbEditar.DisplayFocus = true;
            this.mbEditar.Highlight = true;
            this.mbEditar.Location = new System.Drawing.Point(305, 63);
            this.mbEditar.Name = "mbEditar";
            this.mbEditar.Size = new System.Drawing.Size(111, 23);
            this.mbEditar.TabIndex = 2;
            this.mbEditar.Text = "Editar";
            this.mbEditar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbEditar.UseSelectable = true;
            this.mbEditar.Click += new System.EventHandler(this.mbEditar_Click);
            // 
            // mbExcluir
            // 
            this.mbExcluir.DisplayFocus = true;
            this.mbExcluir.Highlight = true;
            this.mbExcluir.Location = new System.Drawing.Point(305, 92);
            this.mbExcluir.Name = "mbExcluir";
            this.mbExcluir.Size = new System.Drawing.Size(110, 23);
            this.mbExcluir.TabIndex = 3;
            this.mbExcluir.Text = "Excluir";
            this.mbExcluir.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbExcluir.UseSelectable = true;
            this.mbExcluir.Click += new System.EventHandler(this.mbExcluir_Click);
            // 
            // mbSair
            // 
            this.mbSair.DisplayFocus = true;
            this.mbSair.Highlight = true;
            this.mbSair.Location = new System.Drawing.Point(305, 121);
            this.mbSair.Name = "mbSair";
            this.mbSair.Size = new System.Drawing.Size(111, 23);
            this.mbSair.TabIndex = 4;
            this.mbSair.Text = "Sair";
            this.mbSair.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbSair.UseSelectable = true;
            this.mbSair.Click += new System.EventHandler(this.mbSair_Click);
            // 
            // mlblLogin
            // 
            this.mlblLogin.AutoSize = true;
            this.mlblLogin.Location = new System.Drawing.Point(24, 66);
            this.mlblLogin.Name = "mlblLogin";
            this.mlblLogin.Size = new System.Drawing.Size(41, 19);
            this.mlblLogin.TabIndex = 5;
            this.mlblLogin.Text = "Login";
            this.mlblLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // mlblSenha
            // 
            this.mlblSenha.AutoSize = true;
            this.mlblSenha.Location = new System.Drawing.Point(22, 120);
            this.mlblSenha.Name = "mlblSenha";
            this.mlblSenha.Size = new System.Drawing.Size(44, 19);
            this.mlblSenha.TabIndex = 6;
            this.mlblSenha.Text = "Senha";
            this.mlblSenha.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // mtxtLogin
            // 
            // 
            // 
            // 
            this.mtxtLogin.CustomButton.Image = null;
            this.mtxtLogin.CustomButton.Location = new System.Drawing.Point(127, 1);
            this.mtxtLogin.CustomButton.Name = "";
            this.mtxtLogin.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.mtxtLogin.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.mtxtLogin.CustomButton.TabIndex = 1;
            this.mtxtLogin.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtLogin.CustomButton.UseSelectable = true;
            this.mtxtLogin.CustomButton.Visible = false;
            this.mtxtLogin.Lines = new string[0];
            this.mtxtLogin.Location = new System.Drawing.Point(24, 91);
            this.mtxtLogin.MaxLength = 32767;
            this.mtxtLogin.Name = "mtxtLogin";
            this.mtxtLogin.PasswordChar = '\0';
            this.mtxtLogin.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.mtxtLogin.SelectedText = "";
            this.mtxtLogin.SelectionLength = 0;
            this.mtxtLogin.SelectionStart = 0;
            this.mtxtLogin.ShortcutsEnabled = true;
            this.mtxtLogin.Size = new System.Drawing.Size(149, 23);
            this.mtxtLogin.TabIndex = 7;
            this.mtxtLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtLogin.UseSelectable = true;
            this.mtxtLogin.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.mtxtLogin.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mtxtSenha
            // 
            // 
            // 
            // 
            this.mtxtSenha.CustomButton.Image = null;
            this.mtxtSenha.CustomButton.Location = new System.Drawing.Point(127, 1);
            this.mtxtSenha.CustomButton.Name = "";
            this.mtxtSenha.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.mtxtSenha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.mtxtSenha.CustomButton.TabIndex = 1;
            this.mtxtSenha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtSenha.CustomButton.UseSelectable = true;
            this.mtxtSenha.CustomButton.Visible = false;
            this.mtxtSenha.Lines = new string[0];
            this.mtxtSenha.Location = new System.Drawing.Point(22, 142);
            this.mtxtSenha.MaxLength = 32767;
            this.mtxtSenha.Name = "mtxtSenha";
            this.mtxtSenha.PasswordChar = '*';
            this.mtxtSenha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.mtxtSenha.SelectedText = "";
            this.mtxtSenha.SelectionLength = 0;
            this.mtxtSenha.SelectionStart = 0;
            this.mtxtSenha.ShortcutsEnabled = true;
            this.mtxtSenha.Size = new System.Drawing.Size(149, 23);
            this.mtxtSenha.TabIndex = 8;
            this.mtxtSenha.UseSelectable = true;
            this.mtxtSenha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.mtxtSenha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mtxtId
            // 
            // 
            // 
            // 
            this.mtxtId.CustomButton.Image = null;
            this.mtxtId.CustomButton.Location = new System.Drawing.Point(54, 1);
            this.mtxtId.CustomButton.Name = "";
            this.mtxtId.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.mtxtId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.mtxtId.CustomButton.TabIndex = 1;
            this.mtxtId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtId.CustomButton.UseSelectable = true;
            this.mtxtId.CustomButton.Visible = false;
            this.mtxtId.Enabled = false;
            this.mtxtId.Lines = new string[0];
            this.mtxtId.Location = new System.Drawing.Point(194, 91);
            this.mtxtId.MaxLength = 32767;
            this.mtxtId.Name = "mtxtId";
            this.mtxtId.PasswordChar = '\0';
            this.mtxtId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.mtxtId.SelectedText = "";
            this.mtxtId.SelectionLength = 0;
            this.mtxtId.SelectionStart = 0;
            this.mtxtId.ShortcutsEnabled = true;
            this.mtxtId.Size = new System.Drawing.Size(76, 23);
            this.mtxtId.TabIndex = 10;
            this.mtxtId.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtxtId.UseSelectable = true;
            this.mtxtId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.mtxtId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mlblId
            // 
            this.mlblId.AutoSize = true;
            this.mlblId.Location = new System.Drawing.Point(194, 66);
            this.mlblId.Name = "mlblId";
            this.mlblId.Size = new System.Drawing.Size(21, 19);
            this.mlblId.TabIndex = 9;
            this.mlblId.Text = "ID";
            this.mlblId.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 333);
            this.Controls.Add(this.mtxtId);
            this.Controls.Add(this.mlblId);
            this.Controls.Add(this.mtxtSenha);
            this.Controls.Add(this.mtxtLogin);
            this.Controls.Add(this.mlblSenha);
            this.Controls.Add(this.mlblLogin);
            this.Controls.Add(this.mbSair);
            this.Controls.Add(this.mbExcluir);
            this.Controls.Add(this.mbEditar);
            this.Controls.Add(this.mbInserir);
            this.Controls.Add(this.MgUsuario);
            this.Name = "FrmPrincipal";
            this.Style = MetroFramework.MetroColorStyle.Green;
            this.Text = "Cripto Login";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MgUsuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroGrid MgUsuario;
        private MetroFramework.Controls.MetroButton mbInserir;
        private MetroFramework.Controls.MetroButton mbEditar;
        private MetroFramework.Controls.MetroButton mbExcluir;
        private MetroFramework.Controls.MetroButton mbSair;
        private MetroFramework.Controls.MetroLabel mlblLogin;
        private MetroFramework.Controls.MetroLabel mlblSenha;
        private MetroFramework.Controls.MetroTextBox mtxtLogin;
        private MetroFramework.Controls.MetroTextBox mtxtSenha;
        private MetroFramework.Controls.MetroTextBox mtxtId;
        private MetroFramework.Controls.MetroLabel mlblId;
    }
}

