﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CriptoApp
{
    public partial class FrmPrincipal : MetroFramework.Forms.MetroForm
    {
        private Cripto b;
        SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Programas\\CriptoApp\\DbLogin.mdf;Integrated Security=True");

        public FrmPrincipal()
        {
            InitializeComponent();
            b = new Cripto();
        }

        public void CarregaMdgv()
        {
            String query = "SELECT * FROM Usuario";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable usuario = new DataTable();
            da.Fill(usuario);
            this.MgUsuario.DataSource = usuario;
            conn.Close();
        }

        private void mbSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            CarregaMdgv();
        }

        private void mbInserir_Click(object sender, EventArgs e)
        {
            try
            {
                string senha = b.Base64Encode(mtxtSenha.Text);
                conn.Open();
                SqlCommand cmd = new SqlCommand("InserirUsuario", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@login", SqlDbType.NChar).Value = mtxtLogin.Text.Trim();
                cmd.Parameters.AddWithValue("@senha", SqlDbType.NChar).Value = senha;
                cmd.ExecuteNonQuery();
                MetroFramework.MetroMessageBox.Show(this, "Usuário cadastrado com sucesso!", "Inserir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
                CarregaMdgv();
                mtxtLogin.Text = "";
                mtxtSenha.Text = "";
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void mbEditar_Click(object sender, EventArgs e)
        {
            try
            {
                string senha = b.Base64Encode(mtxtSenha.Text);
                conn.Open();
                SqlCommand cmd = new SqlCommand("AtualizarUsuario", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(mtxtId.Text.Trim());
                cmd.Parameters.AddWithValue("@login", SqlDbType.NChar).Value = mtxtLogin.Text.Trim();
                cmd.Parameters.AddWithValue("@senha", SqlDbType.NChar).Value = senha;
                cmd.ExecuteNonQuery();
                MetroFramework.MetroMessageBox.Show(this, "Usuário atualizado com sucesso!", "Atualizar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
                CarregaMdgv();
                mtxtId.Text = "";
                mtxtLogin.Text = "";
                mtxtSenha.Text = "";
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void mbExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("ExcluirUsuario", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(mtxtId.Text.Trim());
                cmd.ExecuteNonQuery();
                MetroFramework.MetroMessageBox.Show(this, "Usuário excluído com sucesso!", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
                CarregaMdgv();
                mtxtId.Text = "";
                mtxtLogin.Text = "";
                mtxtSenha.Text = "";
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void MgUsuario_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.MgUsuario.Rows[e.RowIndex];
                mtxtId.Text = row.Cells[0].Value.ToString();
                mtxtLogin.Text = row.Cells[1].Value.ToString();
                mtxtSenha.Text = row.Cells[2].Value.ToString();
            }
        }
    }
}
