﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace WFAppGrafico
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("server=localhost;port=3306;database=aula;user id=root;password=;charset=utf8");
            string sql = "SELECT serie,COUNT(id) as total FROM aluno GROUP BY serie";
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader mydatareader;
            try
            {
                con.Open();
                mydatareader = cmd.ExecuteReader();
                while (mydatareader.Read())
                {
                    this.gMySQL.Series["Total"].Points.AddXY(mydatareader.GetString("serie"),mydatareader.GetInt32("total"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
