﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTimer
{
    public partial class Form1 : Form
    {
        public int timeLeft { get; set; }
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft = timeLeft - 1;
                var timespan = TimeSpan.FromSeconds(timeLeft);
                txtTimer.Text = timespan.ToString(@"mm\:ss");
            }
            else
            {
                timer1.Stop();
                SystemSounds.Exclamation.Play();
                MessageBox.Show("O tempo expirou!");
            }
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            if (txtTimer.Text == "00:00")
            {
                MessageBox.Show("Por favor, digite algum minuto ou segundos no campo!");
            }
            else
            {
                string[] totalSeconds = txtTimer.Text.Split(':');
                int minutes = Convert.ToInt32(totalSeconds[0]);
                int seconds = Convert.ToInt32(totalSeconds[1]);
                timeLeft = (minutes * 60) + seconds;
                txtTimer.ReadOnly = true;
                timer1.Start();
            }
        }

        private void btnParar_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtTimer.Text = "00:00";
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtTimer.Text = "00:00";
        }
    }
}
